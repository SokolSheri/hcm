<div class="footer">
  <i class='fab fa-facebook icon1'></i>
  <i class='fab fa-twitter icon2'></i>
</div>
</body>
</html>
